---
title: about
layout: about
---

- 👋 Hi, This is "No Such View", yea another new Podcast.
  
- 🌎 We've launched at 2022/09/25.
  
- 🌱 At leisure, let us waste some time. No more view, no more value, only talk nonsense.
  
- 👀 Listen at:
  - No Platfrom online yet.
  
- 💞️ Fell free to contact us:
  - E-Mail: NoSuchView@Outlook.com
  - Github: https://github.com/NoSuchView/
